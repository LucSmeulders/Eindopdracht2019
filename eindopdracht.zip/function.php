<?php

function relocator($path){
  header('Location: '.$path);
}
